"""LintAI - AI-powered linting tool for code quality and validation."""

__version__ = "0.1.0"
__author__ = "Arush Kali"
__email__ = "warush23@gmail.com"
