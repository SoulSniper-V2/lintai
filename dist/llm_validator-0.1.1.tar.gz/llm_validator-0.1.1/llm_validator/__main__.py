"""Entry point for: python -m llm_validator"""
from .cli import cli
if __name__ == "__main__":
    cli()
